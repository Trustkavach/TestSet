Changelog
=========

4.0.0 (under development)
++++++++++++++++++++++++++

Breaking changes
----------------
* Remove support for Python 2.7 and 3.8. The minimum supported version is now Python 3.9.
* The ``pycryptodomex`` package (``Cryptodome`` namespace) is no longer released.
  The library is only available as ``pycryptodome``, under the ``Crypto`` namespace.
* The self-tests are now run by ``pytest``, which must be installed for
  ``python -m Crypto.SelfTest`` to work.
* Remove the ``test`` command of ``setup.py``. Install the package
  (e.g. with ``pip install -e .``) and run ``python -m Crypto.SelfTest`` instead.
* The output length must be a proper integer (``bool`` is rejected) in ``read()``
  of SHAKE, cSHAKE, TurboSHAKE and KangarooTwelve objects, and for
  ``digest_bytes`` and ``digest_bits`` of BLAKE2b and BLAKE2s.
  Before, ``True`` was accepted as 1 and produced a 1-byte output.

Resolved issues
---------------
* ElGamal key objects could not be compared for equality.
* Comparing an RSA, DSA or ElGamal key with an object of a different type now
  returns ``False`` instead of raising ``AttributeError``.
* The legacy ``can_decrypt()`` method of PKCS#1 ciphers raised ``AttributeError``
  and not a boolean.
* The ``update()`` method for SIV encryption objects now returns the cipher object,
  like for other AEAD modes.
* Fixed the method ``new()`` of KMAC256 and TupleHash256 objects:
  it created a KMAC128 or TupleHash128 object instead (for KMAC, also accepting
  keys shorter than the 32 bytes required for KMAC256).
* Added the missing documentation for ``Crypto.Hash.MD4``.
* Salsa20 never returned when encrypting or decrypting 4 GiB or more in a single call.
* The package metadata declares the license as an SPDX expression
  (``BSD-2-Clause AND Unlicense``, PEP 639), which tools can process.
  SipHash (used internally for side-channel countermeasures) has been
  reimplemented, as the previous code was under the CC0 license.

New features
------------
* New function ``Crypto.Hash.KangarooTwelve.digest()``, to hash a whole message
  with a single call. For messages up to 8 KiB, it is 1.3x to 3x faster than
  ``new()`` followed by ``read()``.
* On x86-64 CPUs with AVX2 and BMI2 (gcc and clang only), the Keccak-based hashes
  use a build that takes advantage of those instructions:
  SHA-3, SHAKE, cSHAKE, KMAC, TupleHash and TurboSHAKE are about 1.25x-1.4x faster
  on long messages, and KangarooTwelve hashes 4 leaves in parallel
  (2x to 2.3x faster for messages of 1 MiB or more).
* New parameter ``threads`` for the CTR mode (all block ciphers) and for the GCM and OCB modes,
  to encrypt and decrypt long data on several CPU cores (``threads=0`` for all of them).
  The output does not depend on the number of threads.
* GCM mode is about 1.5x faster on long messages, as it does not copy the data
  before authenticating it.
* The portable GHASH (GCM mode, for CPUs without PCLMULQDQ) no longer uses
  key-dependent tables: it is now constant-time, with the technique
  described by Thomas Pornin for BearSSL. It is also faster: about 2.8x
  on 64-bit and 3.2x on 32-bit systems.
* On CPython, the ``encrypt()`` and ``decrypt()`` methods of most ciphers
  (block cipher modes ECB, CBC, CFB, OFB, CTR, GCM and OCB, plus ChaCha20, Salsa20
  and ARC4) write their result directly into the returned ``bytes`` object,
  without copying it (for 64 KiB or more). For long data, this is 1.3x to 1.8x faster,
  and up to 3x with threads. The same applies to the ``read()`` method of SHAKE128,
  SHAKE256, cSHAKE, TurboSHAKE and KangarooTwelve, to
  ``Crypto.Hash.KangarooTwelve.digest()``, and to ``Crypto.Util.strxor.strxor()``
  and ``strxor_c()`` (up to 3.6x faster).

3.24.0 (4 October 2026)
++++++++++++++++++++++++++

New features
---------------
* Speed up KangarooTwelve by 50% for long messages (1MB or more).
* New parameter ``threads`` for ``Crypto.Hash.KangarooTwelve.new()``,
  to hash long messages on several CPU cores (``threads=0`` for all of them).
  The output does not depend on the number of threads.

Resolved issues
---------------
* GH#875: Fixed the Object Identifiers (OID) for BLAKE2.
* Fixed a potential DOS attack when decrypting a password-encrypted PKCS#8 key,
  when the iteration count is enourmous. Decryption will now fail if it exceeds
  50M iterations; the limit can be changed or removed  via
  the new ``max_iteration_count`` option. Thanks to afldl for reporting.
* Fixed the maximum number of bytes that GCM should encrypt. Thanks to Loganaden Velvindron.
* Fixed ECC operations on 32-bit Windows (x86) wheels: due to a compiler bug in
  Visual Studio 2022, the modular inversion skipped half of the exponent bits,
  producing wrong results.
* Fixed a bug in KangarooTwelve in the scenario where customization string is very
  long (8190 bytes or longer) and the message to hash is empty.
* GH#922: Fixed incorrect verification of an otherwise valid ECDSA signature,
  when the raw x-coordinate of the computed point is not reduced.
  Thanks to afldl for reporting and Ville Vesilehto for the fix.

Other changes
-------------
* Build Windows wheel with Visual Studio 2022, from Visual Studio 2019.
* Remove support for Python 3.7.

3.23.0 (17 May 2025)
++++++++++++++++++++++++++

New features
---------------
* Added cipher modes Key Wrap (KW, RFC3394) and Key Wrap with Padding (KWP, RFC5649).
  Both are defined also in NIST SP 800-38F.
* Wheels for Windows ARM.

Resolved issues
---------------
* GH#862: For HashEdDSA and Ed448, sign() and verify() modified the state of the XOF.

3.22.0 (16 March 2025)
++++++++++++++++++++++++++

New features
---------------
* Added support for HPKE (RFC 9180).

Resolved issues
---------------
* GH#812: CCM ciphers will now fail before encrypting (or decrypting)
  data beyond the limit imposed by the nonce length.
* GH#846: fix infinite loop with RC4 for data larger than 4GB.
* GH#852: handle correctly invalid PEM files with less than 3 lines.

Other changes
-------------
* Remove support for Python 3.6.

3.21.0 (30 September 2024)
++++++++++++++++++++++++++

New features
---------------
* By setting the PYCRYPTODOME_DISABLE_GMP environment variable,
  the GMP library will not be used even if detected.
* Add support for Curve25519 / X25519.
* Add support for Curve448 / X448.
* Add attribute ``curve`` to EccPoint and EccXPoint classes,
  with the canonical name of the curve.
* GH#781: the label for the SP800_108_Counter KDF may now
  contain zero bytes. Thanks to Julien Rische.
* GH#814: RSA keys for PSS can be imported.

Resolved issues
---------------
* GH#810: fixed negation of Ed25519 points.
* GH#819: accept an RFC5916 ECPrivateKey even if it doesn't
  contain any of the optional elements
  (parameters [0] and publicKey[1]).

Other changes
-------------
* Remove support for Python 3.5.

3.20.0 (9 January 2024)
++++++++++++++++++++++++++

New features
---------------
* Added support for TurboSHAKE128 and TurboSHAKE256.
* Added method ``Crypto.Hash.new()`` to generate a hash
  object given a hash name.
* Added support for AES-GCM encryption of PBES2 and PKCS#8
  containers.
* Added support for SHA-2 and SHA-3 algorithms in PBKDF2
  when creating PBES2 and PKCS#8 containers.
* Export of RSA keys accepts the ``prot_params`` dictionary
  as parameter to control the number of iterations for PBKDF2
  and scrypt.
* C unit tests also run on non-x86 architectures.

Resolved issues
---------------
* GH#787: Fixed autodetect logic for GCC 14 in combination with LTO.

3.19.1 (28 December 2023)
++++++++++++++++++++++++++

Resolved issues
---------------
* Fixed a side-channel leakage with OAEP decryption that could be
  exploited to carry out a Manger attack (CVE-2023-52323). Thanks to Hubert Kario.

3.19.0 (16 September 2023)
++++++++++++++++++++++++++

New features
---------------
* The ``update()`` methods of TupleHash128 and TupleHash256 objects
  can now hash multiple items (byte strings) at once.
  Thanks to Sylvain Pelissier.
* Added support for ECDH, with ``Crypto.Protocol.DH``.

Resolved issues
---------------
* GH#754: due to a bug in ``cffi``, do not use it on Windows with Python 3.12+.

3.18.0 (18 May 2023)
++++++++++++++++++++++++++

New features
---------------
* Added support for DER BOOLEAN encodings.
* The library now compiles on Windows ARM64. Thanks to Niyas Sait.

Resolved issues
---------------
* GH#722: ``nonce`` attribute was not correctly set for XChaCha20_Poly1305 ciphers. Thanks to Liam Haber.
* GH#728: Workaround for a possible x86 emulator bug in Windows for ARM64.
* GH#739: OID encoding for arc 2 didn't accept children larger than 39. Thanks to James.
* Correctly check that the scalar matches the point when importing an ECC private key.

3.17.0 (29 January 2023)
++++++++++++++++++++++++++

New features
---------------
* Added support for the Counter Mode KDF defined in SP 800-108 Rev 1.
* Reduce the minimum tag length for the EAX cipher to 2 bytes.
* An RSA object has 4 new properties for the CRT coefficients:
  ``dp``, ``dq``, ``invq`` and ``invq`` (``invp`` is the same value
  as the existing ``u``).

Resolved issues
---------------
* GH#526: improved typing for ``RSA.construct``.
* GH#534: reduced memory consumption when using a large number
  of cipher objects.
* GH#598: fixed missing error handling for ``Util.number.inverse``.
* GH#629: improved typing for ``AES.new`` and the various
  mode-specific types it returns. Thanks to Greg Werbin.
* GH#653: added workaround for an alleged GCC compiler bug
  that affected Ed25519 code compiled for AVX2.
* GH#658: attribute ``curve`` of an ECC key was not always
  the preferred curve name, as it used to be in v3.15.0
  (independently of the curve name specified when generating
  the key).
* GH#637: fixed typing for legacy modules ``PKCS1_v1_5`` and ``PKCS1_PSS``,
  as their ``verify()`` returned a boolean.
* GH#664: with OCB mode, nonces of maximum length (15 bytes)
  were actually used as 14 bytes nonces.
  After this fix, data that was encrypted in past using the
  (default) nonce length of 15 bytes can still be decrypted
  by reducing the nonce to its first 14 bytes.
* GH#705: improved typing for ``nonce``, ``iv``, and ``IV`` parameters
  of cipher objects.

Other changes
-------------
* Build PyPy wheels only for versions 3.8 and 3.9, and not for 3.7 anymore.

3.16.0 (26 November 2022)
++++++++++++++++++++++++++

New features
------------
* Build wheels for musl Linux. Thanks to Ben Raz.

Resolved issues
---------------
* GH#639: ARC4 now also works with 'keys' as short as 8 bits.
* GH#669: fix segfaults when running in a manylinux2010 i686 image.

3.15.0 (22 June 2022)
++++++++++++++++++++++++++

New features
------------
* Add support for curves Ed25519 and Ed448, including export and import of keys.
* Add support for EdDSA signatures.
* Add support for Asymmetric Key Packages (RFC5958) to import private keys.

Resolved issues
---------------
* GH#620: for ``Crypto.Util.number.getPrime`` , do not sequentially
  scan numbers searching for a prime.

3.14.1 (5 February 2022)
++++++++++++++++++++++++++

Resolved issues
---------------
* GH#595: Fixed memory leak for GMP integers.
  Thanks to Witalij Siebert and Pablo Quílez.

3.14.0 (30 January 2022)
++++++++++++++++++++++++++

New features
------------
* Add support for curve NIST P-192.

3.13.0 (23 January 2022)
++++++++++++++++++++++++++

New features
------------
* Add support for curve NIST P-224.

Resolved issues
---------------
* GH#590: Fixed typing info for ``Crypto.PublicKey.ECC``.

Other changes
-------------
* Relaxed ECDSA requirements for FIPS 186 signatures and accept any SHA-2 or SHA-3 hash.
  ``sign()`` and ``verify()`` will be performed even if the hash is stronger than the ECC key.

3.12.0 (4 December 2021)
++++++++++++++++++++++++++

New features
------------
* ECC keys in the SEC1 format can be exported and imported.
* Add support for KMAC128, KMAC256, TupleHash128, and TupleHash256 (NIST SP-800 185).
* Add support for KangarooTwelve.

Resolved issues
---------------
* GH#563: An asymmetric key could not be imported as a ``memoryview``.
* GH#566: cSHAKE128/256 generated a wrong output for customization strings
  longer than 255 bytes.
* GH#582: CBC decryption generated the wrong plaintext when the input and the output were the same buffer.
  Thanks to Michael K. Ashburn.

3.11.0 (8 October 2021)
++++++++++++++++++++++++++

Resolved issues
---------------
* GH#512: Especially for very small bit sizes, ``Crypto.Util.number.getPrime()`` was
  occasionally generating primes larger than given the bit size. Thanks to Koki Takahashi.
* GH#552: Correct typing annotations for ``PKCS115_Cipher.decrypt()``.
* GH#555: ``decrypt()`` method of a PKCS#1v1.5 cipher returned a ``bytearray`` instead of ``bytes``.
* GH#557: External DSA domain parameters were accepted even when the modulus (``p``) was not prime.
  This affected ``Crypto.PublicKey.DSA.generate()`` and ``Crypto.PublicKey.DSA.construct()``.
  Thanks to Koki Takahashi.

New features
------------
* Added cSHAKE128 and cSHAKE256 (of SHA-3 family). Thanks to Michael Schaffner.
* GH#558: The flag RTLD_DEEPBIND passed to ``dlopen()`` is not well supported by
  `address sanitizers <https://github.com/google/sanitizers/issues/611>`_.
  It is now possible to set the environment variable ``PYCRYPTDOME_DISABLE_DEEPBIND``
  to drop that flag and allow security testing.

3.10.4 (25 September 2021)
++++++++++++++++++++++++++

Resolved issues
---------------
* Output of ``Crypto.Util.number.long_to_bytes()`` was not always a multiple of ``blocksize``.

3.10.3 (22 September 2021)
++++++++++++++++++++++++++

Resolved issues
---------------
* GH#376: Fixed symbol conflict between different versions of ``libgmp``.
* GH#481: Improved robustness of PKCS#1v1.5 decryption against timing attacks.
* GH#506 and GH#509: Fixed segmentation faults on Apple M1 and other Aarch64 SoCs,
  when the GMP library was accessed via ``ctypes``. Do not use GMP's own sscanf
  and snprintf routines: instead, use simpler conversion routines.
* GH#510: Workaround for ``cffi`` calling ``ctypes.util.find_library()``, which
  invokes ``gcc`` and ``ld`` on Linux, considerably slowing down all imports.
  On certain configurations, that may also leave temporary files behind.
* GH#517: Fix RSAES-OAEP, as it didn't always fail when zero padding was incorrect.

New features
------------
* Added support for SHA-3 hash functions to HMAC.

Other changes
-------------
* The Windows wheels of Python 2.7 now require the VS2015 runtime to be installed in the system,
  because Microsoft stopped distributing the VS2008 compiler in April 2021.
  VS2008 was used to compile the Python 2.7 extensions.

3.10.1 (9 February 2021)
++++++++++++++++++++++++

Other changes
-------------
* Python 3 wheels use ``abi3`` ABI tag.
* Remove Appveyor CI.

3.10.0 (6 February 2021)
++++++++++++++++++++++++

Resolved issues
---------------
* Fixed a potential memory leak when initializing block ciphers.
* GH#466: ``Crypto.Math.miller_rabin_test()`` was still using the system random
  source and not the one provided as parameter.
* GH#469: RSA objects have the method ``public_key()`` like ECC objects.
  The old method ``publickey()`` is still available for backward compatibility.
* GH#476: ``Crypto.Util.Padding.unpad()`` was raising an incorrect exception
  in case of zero-length inputs. Thanks to Captainowie.
* GH#491: better exception message when ``Counter.new()`` is called with an integer
  ``initial_value`` than doesn't fit into ``nbits`` bits.
* GH#496: added missing ``block_size`` member for ECB cipher objects. Thanks to willem.
* GH#500: ``nonce`` member of an XChaCha20 cipher object was not matching the original nonce.
  Thanks to Charles Machalow.

Other changes
-------------
* The bulk of the test vectors have been moved to the separate
  package ``pycryptodome-test-vectors``. As result, packages ``pycryptodome`` and
  ``pycryptodomex`` become significantly smaller (from 14MB to 3MB).
* Moved CI tests and build service from Travis CI to GitHub Actions.

Breaks in compatibility
-----------------------
* Drop support for Python 2.6 and 3.4.

3.9.9 (2 November 2020)
+++++++++++++++++++++++

Resolved issues
---------------
* GH#435: Fixed ``Crypto.Util.number.size`` for negative numbers.

New features
------------
* Build Python 3.9 wheels on Windows.

3.9.8 (23 June 2020)
++++++++++++++++++++

Resolved issues
---------------
* GH#426: The Shamir's secret sharing implementation is not actually compatible with ``ssss``.
  Added an optional parameter to enable interoperability.
* GH#427: Skip altogether loading of ``gmp.dll`` on Windows.
* GH#420: Fix incorrect CFB decryption when the input and the output are the same buffer.

New features
------------
* Speed up Shamir's secret sharing routines. Thanks to ncarve.

3.9.7 (20 February 2020)
++++++++++++++++++++++++

Resolved issues
---------------
* GH#381: Make notarization possible again on OS X when using wheels.
  Thanks to Colin Atkinson.

3.9.6 (2 February 2020)
++++++++++++++++++++++++

Resolved issues
---------------
* Fix building of wheels for OS X by explicitly setting `sysroot` location.

3.9.5 (1 February 2020)
++++++++++++++++++++++++

Resolved issues
---------------
* RSA OAEP decryption was not verifying that all ``PS`` bytes are zero.
* GH#372: fixed memory leak for operations that use memoryviews when `cffi` is not installed.
* Fixed wrong ASN.1 OID for HMAC-SHA512 in PBE2.

New features
------------
* Updated Wycheproof test vectors to version 0.8r12.

3.9.4 (18 November 2019)
++++++++++++++++++++++++

Resolved issues
---------------
* GH#341: Prevent ``key_to_english`` from creating invalid data when fed with
  keys of length not multiple of 8. Thanks to vstoykovbg.
* GH#347: Fix blocking RSA signing/decryption when key has very small factor.
  Thanks to Martijn Pieters.

3.9.3 (12 November 2019)
++++++++++++++++++++++++

Resolved issues
---------------
* GH#308: Align stack of functions using SSE2 intrinsics to avoid crashes,
  when compiled with gcc on 32-bit x86 platforms.

3.9.2 (10 November 2019)
++++++++++++++++++++++++

New features
------------
* Add Python 3.8 wheels for Mac.

Resolved issues
---------------
* GH#308: Avoid allocating arrays of ``__m128i`` on the stack, to cope with buggy compilers.
* GH#322: Remove blanket ``-O3`` optimization for gcc and clang, to cope with buggy compilers.
* GH#337: Fix typing stubs for signatures.
* GH#338: Deal with gcc installations that don't have ``x86intrin.h``.

3.9.1 (1 November 2019)
++++++++++++++++++++++++

New features
------------
* Add Python 3.8 wheels for Linux and Windows.

Resolved issues
---------------

* GH#328: minor speed-up when importing RSA.

3.9.0 (27 August 2019)
+++++++++++++++++++++++

New features
------------

* Add support for loading PEM files encrypted with AES256-CBC.
* Add support for XChaCha20 and XChaCha20-Poly1305 ciphers.
* Add support for bcrypt key derivation function (``Crypto.Protocol.KDF.bcrypt``).
* Add support for left multiplication of an EC point by a scalar.
* Add support for importing ECC and RSA keys in the new OpenSSH format.

Resolved issues
---------------

* GH#312: it was not possible to invert an EC point anymore.
* GH#316: fix printing of DSA keys.
* GH#317: ``DSA.generate()`` was not always using the ``randfunc`` input.
* GH#285: the MD2 hash had block size of 64 bytes instead of 16; as result the HMAC construction gave incorrect results.

3.8.2 (30 May 2019)
+++++++++++++++++++++++

Resolved issues
---------------

* GH#291: fix strict aliasing problem, emerged with GCC 9.1.

3.8.1 (4 April 2019)
+++++++++++++++++++++++

New features
------------

* Add support for loading PEM files encrypted with AES192-CBC and AES256-GCM.
* When importing ECC keys in PEM format, ignore the redundant EC PARAMS section that was included by certain openssl commands.

Resolved issues
---------------

* ``repr()`` did not work for ``ECC.EccKey`` objects.
* Fix installation in development mode (``setup install develop`` or ``pip install -e .``).
* Minimal length for Blowfish cipher is 32 bits, not 40 bits.
* Various updates to docs.

3.8.0 (23 March 2019)
+++++++++++++++++++++++

New features
------------

* Speed-up ECC performance. ECDSA is 33 times faster on the NIST P-256 curve.
* Added support for NIST P-384 and P-521 curves.
* ``EccKey`` has new methods ``size_in_bits()`` and ``size_in_bytes()``.
* Support HMAC-SHA224, HMAC-SHA256, HMAC-SHA384, and HMAC-SHA512 in PBE2/PBKDF2.

Resolved issues
---------------

* DER objects were not rejected if their length field had a leading zero.
* Allow legacy RC2 ciphers to have 40-bit keys.
* ASN.1 Object IDs did not allow the value 0 in the path.

Breaks in compatibility
-----------------------

* ``point_at_infinity()`` becomes an instance method for ``Crypto.PublicKey.ECC.EccKey``, from a static one.

3.7.3 (19 January 2019)
+++++++++++++++++++++++

Resolved issues
---------------

* GH#258: False positive on PSS signatures when externally provided salt is too long.
* Include type stub files for ``Crypto.IO`` and ``Crypto.Util``.

3.7.2 (26 November 2018)
++++++++++++++++++++++++

Resolved issues
---------------

* GH#242: Fixed compilation problem on ARM platforms.

3.7.1 (25 November 2018)
++++++++++++++++++++++++

New features
------------

* Added type stubs to enable static type checking with mypy. Thanks to Michael Nix.
* New ``update_after_digest`` flag for CMAC.

Resolved issues
---------------

* GH#232: Fixed problem with gcc 4.x when compiling ``ghash_clmul.c``.
* GH#238: Incorrect digest value produced by CMAC after cloning the object.
* Method ``update()`` of an EAX cipher object was returning the underlying CMAC object,
  instead of the EAX object itself.
* Method ``update()`` of a CMAC object was not throwing an exception after the digest
  was computed (with ``digest()`` or ``verify()``).

3.7.0 (27 October 2018)
+++++++++++++++++++++++

New features
------------

* Added support for Poly1305 MAC (with AES and ChaCha20 ciphers for key derivation).
* Added support for ChaCha20-Poly1305 AEAD cipher.
* New parameter ``output`` for ``Crypto.Util.strxor.strxor``, ``Crypto.Util.strxor.strxor_c``,
  ``encrypt`` and ``decrypt`` methods in symmetric ciphers (``Crypto.Cipher`` package).
  ``output`` is a pre-allocated buffer (a ``bytearray`` or a writeable ``memoryview``)
  where the result must be stored.
  This requires less memory for very large payloads; it is also more efficient when
  encrypting (or decrypting) several small payloads.

Resolved issues
---------------

* GH#266: AES-GCM hangs when processing more than 4GB at a time on x86 with PCLMULQDQ instruction.

Breaks in compatibility
-----------------------

* Drop support for Python 3.3.
* Remove ``Crypto.Util.py3compat.unhexlify`` and ``Crypto.Util.py3compat.hexlify``.
* With the old Python 2.6, use only ``ctypes`` (and not ``cffi``) to interface to native code.

3.6.6 (17 August 2018)
++++++++++++++++++++++

Resolved issues
---------------

* GH#198: Fix vulnerability on AESNI ECB with payloads smaller than 16 bytes (CVE-2018-15560).

3.6.5 (12 August 2018)
++++++++++++++++++++++

Resolved issues
---------------

* GH#187: Fixed incorrect AES encryption/decryption with AES acceleration on x86
  due to gcc's optimization and strict aliasing rules.
* GH#188: More prime number candidates than necessary where discarded as composite
  due to the limited way D values were searched in the Lucas test.
* Fixed ResouceWarnings and DeprecationWarnings.
* Workaround for Python 3.7.0 bug on Windows (https://bugs.python.org/issue34108).

3.6.4 (10 July 2018)
+++++++++++++++++++++

New features
------------

* Build Python 3.7 wheels on Linux, Windows and Mac.

Resolved issues
---------------

* GH#178: Rename ``_cpuid`` module to make upgrades more robust.
* More meaningful exceptions in case of mismatch in IV length (CBC/OFB/CFB modes).
* Fix compilation issues on Solaris 10/11.

3.6.3 (21 June 2018)
+++++++++++++++++++++

Resolved issues
---------------

* GH#175: Fixed incorrect results for CTR encryption/decryption with more than 8 blocks.

3.6.2 (19 June 2018)
+++++++++++++++++++++

New features
------------
* ChaCha20 accepts 96 bit nonces (in addition to 64 bit nonces)
  as defined in RFC7539.
* Accelerate AES-GCM on x86 using PCLMULQDQ instruction.
* Accelerate AES-ECB and AES-CTR on x86 by pipelining AESNI instructions.
* As result of the two improvements above, on x86 (Broadwell):

  - AES-ECB and AES-CTR are 3x faster
  - AES-GCM is 9x faster

Resolved issues
---------------

* On Windows, MPIR library was stilled pulled in if renamed to ``gmp.dll``.

Breaks in compatibility
-----------------------

* In ``Crypto.Util.number``, functions ``floor_div`` and ``exact_div``
  have been removed. Also, ``ceil_div`` is limited to non-negative terms only.

3.6.1 (15 April 2018)
+++++++++++++++++++++

New features
------------
* Added Google Wycheproof tests (https://github.com/google/wycheproof)
  for RSA, DSA, ECDSA, GCM, SIV, EAX, CMAC.
* New parameter ``mac_len`` (length of MAC tag) for CMAC.

Resolved issues
---------------

* In certain circumstances (at counter wrapping, which happens on average after
  32 GB) AES GCM produced wrong ciphertexts.
* Method ``encrypt()`` of AES SIV cipher could be still called,
  whereas only ``encrypt_and_digest()`` is allowed.

3.6.0 (8 April 2018)
++++++++++++++++++++

New features
------------
* Introduced ``export_key`` and deprecated ``exportKey`` for DSA and RSA key
  objects.
* Ciphers and hash functions accept ``memoryview`` objects in input.
* Added support for SHA-512/224 and SHA-512/256.

Resolved issues
---------------

* Reintroduced ``Crypto.__version__`` variable as in PyCrypto.
* Fixed compilation problem with MinGW.

3.5.1 (8 March 2018)
++++++++++++++++++++

Resolved issues
---------------

* GH#142. Fix mismatch with declaration and definition of addmul128.

3.5.0 (7 March 2018)
++++++++++++++++++++

New features
------------
* Import and export of ECC curves in compressed form.
* The initial counter for a cipher in CTR mode can be a byte string
  (in addition to an integer).
* Faster PBKDF2 for HMAC-based PRFs (at least 20x for short passwords,
  more for longer passwords). Thanks to Christian Heimes for pointing
  out the implementation was under-optimized.
* The salt for PBKDF2 can be either a string or bytes (GH#67).
* Ciphers and hash functions accept data as `bytearray`, not just
  binary strings.
* The old SHA-1 and MD5 hash functions are available even when Python's
  own `hashlib` does not include them.

Resolved issues
---------------

* Without libgmp, modular exponentiation (since v3.4.8) crashed
  on 32-bit big-endian systems.

Breaks in compatibility
-----------------------

* Removed support for Python < 2.6.

3.4.12 (5 February 2018)
++++++++++++++++++++++++

Resolved issues
---------------

* GH#129. pycryptodomex could only be installed via wheels.

3.4.11 (5 February 2018)
++++++++++++++++++++++++

Resolved issues
---------------

* GH#121. the record list was still not correct due to PEP3147
  and __pycache__ directories. Thanks again to John O'Brien.

3.4.10 (2 February 2018)
++++++++++++++++++++++++

Resolved issues
---------------

* When creating ElGamal keys, the generator wasn't a square residue:
  ElGamal encryption done with those keys cannot be secure under
  the DDH assumption. Thanks to Weikeng Chen.

3.4.9 (1 February 2018)
+++++++++++++++++++++++

New features
------------
* More meaningful error messages while importing an ECC key.

Resolved issues
---------------

* GH#123 and #125. The SSE2 command line switch was not always passed on 32-bit x86 platforms.
* GH#121. The record list (--record) was not always correctly filled for the
  pycryptodomex package. Thanks to John W. O'Brien.

3.4.8 (27 January 2018)
+++++++++++++++++++++++

New features
------------

* Added a native extension in pure C for modular exponentiation, optimized for SSE2 on x86.
  In the process, we drop support for the arbitrary arithmetic library MPIR
  on Windows, which is painful to compile and deploy.
  The custom  modular exponentiation is 130% (160%) slower on an Intel CPU in 32-bit (64-bit) mode,
  compared to MPIR. Still, that is much faster that CPython's own `pow()` function which
  is 900% (855%) slower than MPIR. Support for the GMP library on Unix remains.
* Added support for *manylinux* wheels.
* Support for Python 3.7.

Resolved issues
---------------

* The DSA parameter 'p' prime was created with 255 bits cleared
  (but still with the correct strength).
* GH#106. Not all docs were included in the tar ball.
  Thanks to Christopher Hoskin.
* GH#109. ECDSA verification failed for DER encoded signatures.
  Thanks to Alastair Houghton.
* Human-friendly messages for padding errors with ECB and CBC.

3.4.7 (26 August 2017)
++++++++++++++++++++++

New features
------------

* API documentation is made with sphinx instead of epydoc.
* Start using ``importlib`` instead of ``imp`` where available.

Resolved issues
---------------

* GH#82. Fixed PEM header for RSA/DSA public keys.

3.4.6 (18 May 2017)
+++++++++++++++++++++++

Resolved issues
---------------

* GH#65. Keccak, SHA3, SHAKE and the seek functionality for ChaCha20 were
  not working on big endian machines. Fixed. Thanks to Mike Gilbert.
* A few fixes in the documentation.

3.4.5 (6 February 2017)
+++++++++++++++++++++++

Resolved issues
---------------

* The library can also be compiled using MinGW.

3.4.4 (1 February 2017)
+++++++++++++++++++++++

Resolved issues
---------------

* Removed use of ``alloca()``.
* [Security] Removed implementation of deprecated "quick check" feature of PGP block cipher mode.
* Improved the performance of ``scrypt`` by converting some Python to C.

3.4.3 (17 October 2016)
+++++++++++++++++++++++

Resolved issues
---------------

* Undefined warning was raised with libgmp version < 5
* Forgot inclusion of ``alloca.h``
* Fixed a warning about type mismatch raised by recent versions of cffi

3.4.2 (8 March 2016)
++++++++++++++++++++


Resolved issues
---------------

* Fix renaming of package for ``install`` command.


3.4.1 (21 February 2016)
++++++++++++++++++++++++

New features
------------

* Added option to install the library under the ``Cryptodome`` package
  (instead of ``Crypto``).

3.4 (7 February 2016)
+++++++++++++++++++++

New features
------------

* Added ``Crypto.PublicKey.ECC`` module (NIST P-256 curve only), including export/import of ECC keys.
* Added support for ECDSA (FIPS 186-3 and RFC6979).
* For CBC/CFB/OFB/CTR cipher objects, ``encrypt()`` and ``decrypt()`` cannot be intermixed.
* CBC/CFB/OFB, the cipher objects have both ``IV`` and ``iv`` attributes.
  ``new()`` accepts ``IV`` as well as ``iv`` as parameter.
* For CFB/OPENPGP cipher object, ``encrypt()`` and ``decrypt()`` do not require the plaintext
  or ciphertext pieces to have length multiple of the CFB segment size.
* Added dedicated tests for all cipher modes, including NIST test vectors
* CTR/CCM/EAX/GCM/SIV/Salsa20/ChaCha20 objects expose the ``nonce`` attribute.
* For performance reasons, CCM cipher optionally accepted a pre-declaration of
  the length of the associated data, but never checked if the actual data passed
  to the cipher really matched that length. Such check is now enforced.
* CTR cipher objects accept parameter ``nonce`` and possibly ``initial_value`` in
  alternative to ``counter`` (which is deprecated).
* All ``iv``/``IV`` and ``nonce`` parameters are optional. If not provided,
  they will be randomly generated (exception: ``nonce`` for CTR mode in case
  of block sizes smaller than 16 bytes).
* Refactored ARC2 cipher.
* Added ``Crypto.Cipher.DES3.adjust_key_parity()`` function.
* Added ``RSA.import_key`` as an alias to the deprecated ``RSA.importKey``
  (same for the ``DSA`` module).
* Added ``size_in_bits()`` and ``size_in_bytes()`` methods to ``RsaKey``.

Resolved issues
---------------

* RSA key size is now returned correctly in ``RsaKey.__repr__()`` method (kudos to *hannesv*).
* CTR mode does not modify anymore ``counter`` parameter passed to ``new()`` method.
* CTR raises ``OverflowError`` instead of ``ValueError`` when the counter wraps around.
* PEM files with Windows newlines could not be imported.
* ``Crypto.IO.PEM`` and ``Crypto.IO.PKCS8`` used to accept empty passphrases.
* GH#6: NotImplementedError now raised for unsupported methods ``sign``, ``verify``,
  ``encrypt``, ``decrypt``, ``blind``, ``unblind`` and ``size`` in objects ``RsaKey``, ``DsaKey``,
  ``ElGamalKey``.

Breaks in compatibility
-----------------------

* Parameter ``segment_size`` cannot be 0 for the CFB mode.
* For OCB ciphers, a final call without parameters to ``encrypt`` must end a sequence
  of calls to ``encrypt`` with data (similarly for ``decrypt``).
* Key size for ``ARC2``, ``ARC4`` and ``Blowfish`` must be at least 40 bits long (still very weak).
* DES3 (Triple DES module) does not allow keys that degenerate to Single DES.
* Removed method ``getRandomNumber`` in ``Crypto.Util.number``.
* Removed module ``Crypto.pct_warnings``.
* Removed attribute ``Crypto.PublicKey.RSA.algorithmIdentifier``.

3.3.1 (1 November 2015)
+++++++++++++++++++++++

New features
------------

* Opt-in for ``update()`` after ``digest()`` for SHA-3, keccak, BLAKE2 hashes

Resolved issues
---------------

* Removed unused SHA-3 and keccak test vectors, therefore significantly reducing
  the package from 13MB to 3MB.

Breaks in compatibility
-----------------------

* Removed method ``copy()`` from BLAKE2 hashes
* Removed ability to ``update()`` a BLAKE2 hash after the first call to ``(hex)digest()``

3.3 (29 October 2015)
+++++++++++++++++++++

New features
------------

* Windows wheels bundle the MPIR library
* Detection of faults occurring during secret RSA operations
* Detection of non-prime (weak) q value in DSA domain parameters
* Added original Keccak hash family (b=1600 only).
  In the process, simplified the C code base for SHA-3.
* Added SHAKE128 and SHAKE256 (of SHA-3 family)

Resolved issues
---------------

* GH#3: gcc 4.4.7 unhappy about double typedef

Breaks in compatibility
-----------------------

* Removed method ``copy()`` from all SHA-3 hashes
* Removed ability to ``update()`` a SHA-3 hash after the first call to ``(hex)digest()``

3.2.1 (9 September 2015)
++++++++++++++++++++++++

New features
------------

* Windows wheels are automatically built on Appveyor

3.2 (6 September 2015)
++++++++++++++++++++++

New features
------------

* Added hash functions BLAKE2b and BLAKE2s.
* Added stream cipher ChaCha20.
* Added OCB cipher mode.
* CMAC raises an exception whenever the message length is found to be
  too large and the chance of collisions not negligeable.
* New attribute ``oid`` for Hash objects with ASN.1 Object ID
* Added ``Crypto.Signature.pss`` and ``Crypto.Signature.pkcs1_15``
* Added NIST test vectors (roughly 1200) for PKCS#1 v1.5 and PSS signatures.

Resolved issues
---------------

* tomcrypt_macros.h asm error #1

Breaks in compatibility
-----------------------

* Removed keyword ``verify_x509_cert`` from module method ``importKey`` (RSA and DSA).
* Reverted to original PyCrypto behavior of method ``verify`` in ``PKCS1_v1_5``
  and ``PKCS1_PSS``.

3.1 (15 March 2015)
+++++++++++++++++++

New features
------------

* Speed up execution of Public Key algorithms on PyPy, when backed
  by the Gnu Multiprecision (GMP) library.
* GMP headers and static libraries are not required anymore at the time
  PyCryptodome is built. Instead, the code will automatically use the
  GMP dynamic library (.so/.DLL) if found in the system at runtime.
* Reduced the amount of C code by almost 40% (4700 lines).
  Modularized and simplified all code (C and Python) related to block ciphers.
  Pycryptodome is now free of CPython extensions.
* Add support for CI in Windows via Appveyor.
* RSA and DSA key generation more closely follows FIPS 186-4 (though it is
  not 100% compliant).

Resolved issues
---------------

* None

Breaks in compatibility
-----------------------

* New dependency on ctypes with Python 2.4.
* The ``counter`` parameter of a CTR mode cipher must be generated via
  ``Crypto.Util.Counter``. It cannot be a generic callable anymore.
* Removed the ``Crypto.Random.Fortuna`` package (due to lack of test vectors).
* Removed the ``Crypto.Hash.new`` function.
* The ``allow_wraparound`` parameter of ``Crypto.Util.Counter`` is ignored.
  An exception is always generated if the counter is reused.
* ``DSA.generate``, ``RSA.generate`` and ``ElGamal.generate`` do not
  accept the ``progress_func`` parameter anymore.
* Removed ``Crypto.PublicKey.RSA.RSAImplementation``.
* Removed ``Crypto.PublicKey.DSA.DSAImplementation``.
* Removed ambiguous method ``size()`` from RSA, DSA and ElGamal keys.

3.0 (24 June 2014)
++++++++++++++++++

New features
------------

* Initial support for PyPy.
* SHA-3 hash family based on the April 2014 draft of FIPS 202.
  See modules ``Crypto.Hash.SHA3_224/256/384/512``.
  Initial Keccak patch by Fabrizio Tarizzo.
* Salsa20 stream cipher. See module ``Crypto.Cipher.Salsa20``.
  Patch by Fabrizio Tarizzo.
* Colin Percival's ``scrypt`` key derivation function (``Crypto.Protocol.KDF.scrypt``).
* Proper interface to FIPS 186-3 DSA. See module ``Crypto.Signature.DSS``.
* Deterministic DSA (RFC6979). Again, see ``Crypto.Signature.DSS``.
* HMAC-based Extract-and-Expand key derivation function
  (``Crypto.Protocol.KDF.HKDF``, RFC5869).
* Shamir's Secret Sharing protocol, compatible with *ssss* (128 bits only).
  See module ``Crypto.Protocol.SecretSharing``.
* Ability to generate a DSA key given the domain parameters.
* Ability to test installation with a simple ``python -m Crypto.SelfTest``.

Resolved issues
---------------

* LP#1193521: ``mpz_powm_sec()`` (and Python) crashed when modulus was odd.
* Benchmarks work again (they broke when ECB stopped working if
  an IV was passed. Patch by Richard Mitchell.
* LP#1178485: removed some catch-all exception handlers.
  Patch by Richard Mitchell.
* LP#1209399: Removal of Python wrappers caused HMAC to silently
  produce the wrong data with SHA-2 algorithms.
* LP#1279231: remove dead code that does nothing in SHA-2 hashes.
  Patch by Richard Mitchell.
* LP#1327081: AESNI code accesses memory beyond buffer end.
* Stricter checks on ciphertext and plaintext size for textbook RSA
  (kudos to sharego).

Breaks in compatibility
-----------------------

* Removed support for Python < 2.4.
* Removed the following methods from all 3 public key object types (RSA, DSA, ElGamal):

  - ``sign``
  - ``verify``
  - ``encrypt``
  - ``decrypt``
  - ``blind``
  - ``unblind``

  Code that uses such methods is doomed anyway. It should be fixed ASAP to
  use the algorithms available in ``Crypto.Signature`` and ``Crypto.Cipher``.
* The 3 public key object types (RSA, DSA, ElGamal) are now unpickable.
* Symmetric ciphers do not have a default mode anymore (used to be ECB).
  An expression like ``AES.new(key)`` will now fail. If ECB is the desired mode,
  one has to explicitly use ``AES.new(key, AES.MODE_ECB)``.
* Unsuccessful verification of a signature will now raise an exception [reverted in 3.2].
* Removed the ``Crypto.Random.OSRNG`` package.
* Removed the ``Crypto.Util.winrandom`` module.
* Removed the ``Crypto.Random.randpool`` module.
* Removed the ``Crypto.Cipher.XOR`` module.
* Removed the ``Crypto.Protocol.AllOrNothing`` module.
* Removed the ``Crypto.Protocol.Chaffing`` module.
* Removed the parameters ``disabled_shortcut`` and ``overflow`` from ``Crypto.Util.Counter.new``.

Other changes
-------------

* ``Crypto.Random`` stops being a userspace CSPRNG. It is now a pure wrapper over ``os.urandom``.
* Added certain resistance against side-channel attacks for GHASH (GCM) and DSA.
* More test vectors for ``HMAC-RIPEMD-160``.
* Update ``libtomcrypt`` headers and code to v1.17 (kudos to Richard Mitchell).
* RSA and DSA keys are checked for consistency as they are imported.
* Simplified build process by removing autoconf.
* Speed optimization to PBKDF2.
* Add support for MSVC.
* Replaced HMAC code with a BSD implementation. Clarified that starting from the fork,
  all contributions are released under the BSD license.
