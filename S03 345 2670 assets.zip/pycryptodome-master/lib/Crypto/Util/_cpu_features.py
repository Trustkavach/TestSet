# ===================================================================
#
# Copyright (c) 2018, Helder Eijs <helderijs@gmail.com>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===================================================================

from __future__ import annotations

import os

from Crypto.Util._raw_api import load_pycryptodome_raw_lib

_raw_cpuid_lib = load_pycryptodome_raw_lib(
    "Crypto.Util._cpuid_c",
    """
                                           int have_aes_ni(void);
                                           int have_clmul(void);
                                           int have_avx2(void);
                                           int have_bmi1(void);
                                           int have_bmi2(void);
                                           """,
)


def have_aes_ni() -> int:
    return _raw_cpuid_lib.have_aes_ni()


def have_clmul() -> int:
    return _raw_cpuid_lib.have_clmul()


def have_avx2() -> int:
    return _raw_cpuid_lib.have_avx2()


def have_bmi1() -> int:
    return _raw_cpuid_lib.have_bmi1()


def have_bmi2() -> int:
    return _raw_cpuid_lib.have_bmi2()


def available_cores() -> int:
    """Return the number of CPU cores this process can run on."""

    count: int | None
    # Python 3.13+: it takes into account CPU affinity and -X cpu_count
    if hasattr(os, "process_cpu_count"):
        count = os.process_cpu_count()
    elif hasattr(os, "sched_getaffinity"):
        count = len(os.sched_getaffinity(0))
    elif hasattr(os, "cpu_count"):
        count = os.cpu_count()
    else:
        import multiprocessing

        try:
            count = multiprocessing.cpu_count()
        except NotImplementedError:
            count = None
    return count or 1
